<?php 

    $connection = mysqli_connect('Localhost','root','','beauty_store');

?>


